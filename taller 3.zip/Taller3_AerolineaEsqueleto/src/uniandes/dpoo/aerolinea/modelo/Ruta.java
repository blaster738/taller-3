package uniandes.dpoo.aerolinea.modelo;

/**
 * Esta clase tiene la información de una ruta entre dos aeropuertos que cubre una aerolínea.
 */
public class Ruta
{
	private final String codigoRuta;     
	private final Aeropuerto origen;
	private final Aeropuerto destino;
	private final String horaSalida;
	private final String horaLlegada;

	public Ruta(String codigoRuta, Aeropuerto origen, Aeropuerto destino, String horaSalida, String horaLlegada) {
	    if (codigoRuta == null || codigoRuta.isEmpty()) {
	        throw new IllegalArgumentException(" no puede ser nulo o vacío.");
	    }
	    if (origen == null || destino == null) {
	        throw new IllegalArgumentException(" no pueden ser nulos.");
	    }
	    if (origen == destino || (origen.getCodigo() != null && origen.getCodigo().equals(destino.getCodigo()))) {
	        throw new IllegalArgumentException("Origen y destino deben ser diferentes.");
	    }
	    if (horaSalida == null || horaLlegada == null) {
	        throw new IllegalArgumentException(" no pueden ser nulas.");
	    }
	    int hs = getHoras(horaSalida);
	    int ms = getMinutos(horaSalida);
	    int hl = getHoras(horaLlegada);
	    int ml = getMinutos(horaLlegada);
	    if (hs < 0 || hs > 23 || hl < 0 || hl > 23 || ms < 0 || ms > 59 || ml < 0 || ml > 59) {
	        throw new IllegalArgumentException(" fuera de rango.");
	    }

	    this.codigoRuta = codigoRuta;
	    this.origen = origen;
	    this.destino = destino;
	    this.horaSalida = horaSalida;
	    this.horaLlegada = horaLlegada;
	}

	public String getCodigoRuta() {
	    return codigoRuta;
	}

	public Aeropuerto getOrigen() {
	    return origen;
	}

	public Aeropuerto getDestino() {
	    return destino;
	}

	public String getHoraSalida() {
	    return horaSalida;
	}

	public String getHoraLlegada() {
	    return horaLlegada;
	}



    /**
     * Dada una cadena con una hora y minutos, retorna los minutos.
     * 
     * Por ejemplo, para la cadena '715' retorna 15.
     * @param horaCompleta Una cadena con una hora, donde los minutos siempre ocupan los dos últimos caracteres
     * @return Una cantidad de minutos entre 0 y 59
     */
    public static int getMinutos( String horaCompleta )
    {
        int minutos = Integer.parseInt( horaCompleta ) % 100;
        return minutos;
    }

    /**
     * Dada una cadena con una hora y minutos, retorna las horas.
     * 
     * Por ejemplo, para la cadena '715' retorna 7.
     * @param horaCompleta Una cadena con una hora, donde los minutos siempre ocupan los dos últimos caracteres
     * @return Una cantidad de horas entre 0 y 23
     */
    public static int getHoras( String horaCompleta )
    {
        int horas = Integer.parseInt( horaCompleta ) / 100;
        return horas;
    }

    
}
